import sys

# It would be good to use the constants in 'config_app'.
# However, we don't know yet 'config_app'!.
# config_app.DIRECTORY_CONFIG
sys.path.append('config')
# config_app.DIRECTORY_PROGRAM
sys.path.append('program')

from upysh import *

import hw_test_pidh_pido_day
# import hw_test_pidh_pido
# import hw_test_pidh
